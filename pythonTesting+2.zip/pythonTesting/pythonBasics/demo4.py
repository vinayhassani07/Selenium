#import FunctionsDemo as f1
from FunctionsDemo import *

print(AddIntegers(2,3))

GreetMe("hello")

print(dic["a"])